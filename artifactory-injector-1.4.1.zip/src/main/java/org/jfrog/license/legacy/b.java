package org.jfrog.license.legacy;

import org.apache.commons.codec.binary.Base64;
import org.jfrog.license.exception.LicenseException;

public class b
{
	private final JsonLicenseSerializer serializer;

	public b() throws LicenseException {
		this.serializer = new JsonLicenseSerializer();
	}
}
